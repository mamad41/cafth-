create definer = root@localhost view vue_analyse_ventes as
select `p`.`reference_sku`                                                                           AS `reference_sku`,
       `p`.`nom_produit`                                                                             AS `nom_produit`,
       `p`.`stock`                                                                                   AS `stock`,
       `p`.`prix_ht`                                                                                 AS `prix_ht`,
       `p`.`prix_ttc`                                                                                AS `prix_ttc`,
       coalesce(sum(`cd`.`quantite`), 0)                                                             AS `total_ventes`,
       (select count(0) from `cafthe`.`favoris` `f` where `f`.`reference_sku` = `p`.`reference_sku`) AS `total_favoris`
from (`cafthe`.`produit` `p` left join `cafthe`.`commande_details` `cd` on (`p`.`reference_sku` = `cd`.`reference_sku`))
group by `p`.`reference_sku`, `p`.`nom_produit`, `p`.`stock`, `p`.`prix_ht`, `p`.`prix_ttc`;

